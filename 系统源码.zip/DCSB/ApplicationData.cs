﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DCSB
{
    public static class ApplicationData
    {
        public const string db = "nbdata.db";
    }
}
